
# VotreIAPro+

Assistant IA multimétier (juriste 👩‍⚖️ ou médecin 👨‍⚕️), déployable depuis GitHub sur Render ou Hugging Face.

## Fonctionnalités

- Interface IA simple avec Streamlit
- Choix du métier : juriste ou médecin
- Intégration OpenAI (via `openai_key`)
- Prêt à déployer gratuitement

## Déploiement

1. Fork ce dépôt sur GitHub
2. Déploie-le sur [https://render.com](https://render.com) en tant qu'app web Python
3. Ajoute ta clé OpenAI dans les variables d’environnement : `openai_key`
